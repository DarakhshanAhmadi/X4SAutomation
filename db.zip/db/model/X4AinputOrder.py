class X4AInputOrder:
    def __init__(self, feature_file_name, reseller_bcn, reseller_po):
        self.feature_file_name = feature_file_name
        self.reseller_bcn = reseller_bcn
        self.reseller_po = reseller_po
