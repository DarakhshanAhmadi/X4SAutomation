class SqlConstant:
    X4A_INPUT_ORDER_INSERT_SQL_QUERY = "INSERT INTO x4a_input_order(" \
                                         "feature_file_name, reseller_bcn, reseller_po)" \
                                         "VALUES(?, ?, ?)"
